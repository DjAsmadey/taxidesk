package ru.taxidesk.driver

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/** Оболочка: открывает /driver/ на сервере диспетчерской и отдаёт веб-интерфейсу GPS из фоновой службы. */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var pendingTrack: Pair<String, String>? = null

    private val prefs get() = getSharedPreferences("app", Context.MODE_PRIVATE)
    private var server: String
        get() = prefs.getString("server", "") ?: ""
        set(v) { prefs.edit().putString("server", v).apply() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(Bridge(), "AndroidApp")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "http" || u.scheme == "https") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Нет приложения для этой ссылки", Toast.LENGTH_SHORT).show()
                }
                return true
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) v.loadData(errorPage(), "text/html; charset=utf-8", "utf-8")
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }
        })
        ensurePermissions()
        if (server.isEmpty()) askServer() else load()
    }

    private fun errorPage() = """
        <meta name=viewport content='width=device-width'><body style='background:#101820;color:#fff;font:18px sans-serif;padding:24px'>
        <h2>Нет связи с сервером</h2><p>${server}</p>
        <p>Проверьте, что телефон в той же сети (Wi‑Fi), что и компьютер диспетчерской, и что программа запущена.</p>
        <p><a style='color:#4c9aff' href='#' onclick='AndroidApp.reload()'>Повторить</a> · <a style='color:#4c9aff' href='#' onclick='AndroidApp.changeServer()'>Сменить адрес</a></p>
    """.trimIndent()

    private fun load() { web.loadUrl(server.trimEnd('/') + "/driver/") }

    private fun askServer() {
        val input = EditText(this).apply {
            hint = "192.168.1.10:3000"
            setText(server.removePrefix("http://"))
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Адрес сервера диспетчерской")
            .setMessage("Адрес компьютера с программой в той же сети, например 192.168.1.10:3000")
            .setView(input)
            .setCancelable(server.isNotEmpty())
            .setPositiveButton("Подключиться") { _, _ ->
                var v = input.text.toString().trim()
                if (v.isNotEmpty()) {
                    if (!v.startsWith("http://") && !v.startsWith("https://")) v = "http://$v"
                    if (v != server) { stopService(Intent(this, LocationService::class.java)); server = v }
                    load()
                } else if (server.isEmpty()) askServer()
            }
            .show()
    }

    private fun ensurePermissions() {
        val need = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val miss = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (miss.isNotEmpty()) ActivityCompat.requestPermissions(this, miss.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        pendingTrack?.let { (t, o) -> pendingTrack = null; startTracking(t, o) }
    }

    private fun hasLocation() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun startTracking(token: String, origin: String) {
        if (!hasLocation()) { pendingTrack = token to origin; ensurePermissions(); js("window.__nativeGps&&__nativeGps(false)"); return }
        val i = Intent(this, LocationService::class.java).putExtra("token", token).putExtra("origin", origin)
        ContextCompat.startForegroundService(this, i)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private val listener: (Double, Double, Float, Float) -> Unit = { lat, lng, sp, hd -> js("window.__nativePos&&__nativePos($lat,$lng,$sp,$hd)") }
    private val gpsListener: (Boolean) -> Unit = { ok -> js("window.__nativeGps&&__nativeGps($ok)") }

    override fun onStart() { super.onStart(); LocationService.onPos = listener; LocationService.onGps = gpsListener }
    override fun onStop() { super.onStop(); if (LocationService.onPos === listener) { LocationService.onPos = null; LocationService.onGps = null } }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    inner class Bridge {
        @JavascriptInterface fun startTracking(token: String, origin: String) = this@MainActivity.runOnUiThread { this@MainActivity.startTracking(token, origin) }
        @JavascriptInterface fun stopTracking() { stopService(Intent(this@MainActivity, LocationService::class.java)) }
        @JavascriptInterface fun changeServer() = runOnUiThread { askServer() }
        @JavascriptInterface fun reload() = runOnUiThread { load() }
    }
}
