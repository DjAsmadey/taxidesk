package ru.taxidesk.driver

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Фоновая служба: берёт GPS и отправляет позицию водителя на сервер, пока экран выключен или приложение свёрнуто. */
class LocationService : Service(), LocationListener {
    companion object {
        @Volatile var onPos: ((Double, Double, Float, Float) -> Unit)? = null
        @Volatile var onGps: ((Boolean) -> Unit)? = null
    }

    private var token = ""
    private var origin = ""
    private var lastSent = 0L
    private var wake: PowerManager.WakeLock? = null
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var lm: LocationManager

    override fun onBind(i: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let { token = it.getStringExtra("token") ?: token; origin = it.getStringExtra("origin") ?: origin }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("loc", "Местоположение", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this).apply { if (Build.VERSION.SDK_INT >= 26) setChannelId("loc") }
            .setContentTitle(getString(R.string.notif_title)).setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(1, n)
        wake = wake ?: (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "taxidesk:gps").apply { acquire() }
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        lm.removeUpdates(this)
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 5f, this)
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 20f, this)
            onGps?.invoke(lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
        } catch (_: SecurityException) { onGps?.invoke(false) }
        return START_REDELIVER_INTENT
    }

    override fun onLocationChanged(l: Location) {
        val sp = if (l.hasSpeed()) minOf(l.speed, 99f) else 0f
        val hd = if (l.hasBearing()) l.bearing else 0f
        onGps?.invoke(true)
        onPos?.invoke(l.latitude, l.longitude, sp, hd)
        val t = System.currentTimeMillis()
        if (t - lastSent < 2500) return
        lastSent = t
        val body = """{"lat":${l.latitude},"lng":${l.longitude},"speed":$sp,"heading":$hd}"""
        io.execute {
            try {
                val c = URL("$origin/api/driver/position").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 5000; c.readTimeout = 5000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer $token")
                c.outputStream.use { it.write(body.toByteArray()) }
                c.responseCode; c.disconnect()
            } catch (_: Exception) { /* сеть пропала — следующая точка уйдёт позже */ }
        }
    }

    @Deprecated("old API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
    override fun onProviderEnabled(p: String) { onGps?.invoke(true) }
    override fun onProviderDisabled(p: String) { onGps?.invoke(false) }

    override fun onDestroy() {
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        wake?.takeIf { it.isHeld }?.release(); wake = null
        io.shutdown(); super.onDestroy()
    }
}
