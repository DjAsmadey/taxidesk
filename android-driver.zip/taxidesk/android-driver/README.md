# TaxiDesk Водитель — Android

Оболочка вокруг веб-приложения водителя (`/driver/` на сервере диспетчерской):
- на весь экран карта, свободные заказы — ★, назначенный заказ — карточка (адреса, тариф, комментарий, сумма, оплата) и маршрут;
- GPS работает в фоновой службе с уведомлением, позиция уходит на сервер и при выключенном экране;
- адрес сервера вводится один раз (`192.168.1.10:3000`), меняется в меню или на экране входа.

## Сборка
1. Android Studio: File → Open → папка `android-driver`, Run (или Build → Build APK).
2. Командой: `cd android-driver && gradle wrapper --gradle-version 8.7 && ./gradlew assembleDebug`
   → `app/build/outputs/apk/debug/app-debug.apk` (JDK 17, Android SDK 34).
3. Без установки среды: залить проект на GitHub — workflow `.github/workflows/build-apk.yml` соберёт APK (Actions → Run workflow).

Установка: скопируйте APK на телефон, разрешите установку из неизвестных источников.
